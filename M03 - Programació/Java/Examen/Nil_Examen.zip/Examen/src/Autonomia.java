public interface Autonomia {
    float getAutonomia();
}

