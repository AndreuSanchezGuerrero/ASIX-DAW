//li passem un array que haura de ordenar per el preu
public interface Comparable {
    //Metode per comparar dos objectes
    public int compareTo(Object o);
}
