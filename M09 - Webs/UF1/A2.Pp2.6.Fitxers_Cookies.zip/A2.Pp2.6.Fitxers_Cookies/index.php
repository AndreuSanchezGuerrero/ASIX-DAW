    <!-- -->
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" type="text/css" href="CSS.css">
            <title>Exercicis</title>
            <h1>Exercicis</h1>
            <title>Exercisis</title>
        </head>
        <body>
            <a href="Ex1.html"><button>Exercici 1</button></a>
            <a href="Ex2.php"><button>Exercici 2</button></a>
            <a href="Ex3.html"><button>Exercici 3</button></a>
