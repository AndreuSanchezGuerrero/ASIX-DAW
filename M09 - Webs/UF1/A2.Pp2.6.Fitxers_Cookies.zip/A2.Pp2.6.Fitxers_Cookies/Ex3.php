<!-- Exercici 3: Implementa dues pantalles. A la primera hi ha d’haver quatre opcions (fes servir formulari de inputs de tipus radios button) que posteriorment podríem utilitzar per valorar exposicions (millorable, suficient, bé i molt bé). I a la segona s’ha de mostrar per pantalla els cops que s’ha escollit cada opció, també un botó o link per tornar a la pàgina del formulari i poder seguir valorant. (4.0p)
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="CSS.css">
        <title>Exercici 3</title>
    </head>
    <body>
        <h1>Exercici 3</h1>
        <form action="Ex3.php" method="post">
            <input type="radio" name="opcio" value="millorable">Millorable<br>
            <input type="radio" name="opcio" value="suficient">Suficient<br>
            <input type="radio" name="opcio" value="be">Be<br>
            <input type="radio" name="opcio" value="moltbe">Molt Be<br>
            <input type="submit" value="Enviar">
        </form>
    </body>
</html>
-->
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="CSS.css">
        <title>Exercici 3</title>
    </head>
    <body>
        <h1>Exercici 3</h1>
        <?php
        #Enmagatzemem la resposta en un fitxer i mostrem les cantits de cadascun en el fitxer
        $fitxer = fopen("Ex3.txt", "a");
        #agafem la opcio q ha marcat i l'afegim al contador del fitxer
        $opcio = $_POST["opcio"];
        while (!feof($fitxer)) {
            $line = fgets($fitxer);
            $opcio = substr($line, 0, strpos($line, "="));
            $contador = substr($line, strpos($line, "=") + 1, strlen($line));
        }
        fwrite($fitxer, $opcio . "=" . $contador . " ");
        fclose($fitxer);
        $fitxer = fopen("Ex3.txt", "r");
        while (!feof($fitxer)) {
            $line = fgets($fitxer);
            $opcio = substr($line, 0, strpos($line, "="));
            $contador = substr($line, strpos($line, "=") + 1, strlen($line));
            echo $opcio . " = " . $contador . "<br>";
        }
        ?>
    <a href="index.php"><button>Tornar</button></a>
    </body>
</html>

