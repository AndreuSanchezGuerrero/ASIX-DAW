    <!-- -->
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" type="text/css" href="CSS.css">
            <title>Exercicis</title>
        </head>
        <body>
            <h1>Exercicis</h1>
            <a href="Ex1.php"><button>Exercici 1</button></a>
            <a href="Ex2.php"><button>Exercici 2</button></a>
            <a href="Ex3.php"><button>Exercici 3</button></a>
            <a href="Ex4.php"><button>Exercici 4</button></a>
            <a href="Ex5.php"><button>Exercici 5</button></a>
        </body>
    </html>
