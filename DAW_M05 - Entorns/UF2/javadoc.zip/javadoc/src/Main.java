
import java.awt.*;

public class Main {
    
    /** 
     * @param args
     */
    public static void main(String[] args) {
        new Menu().menuPrincipal();
    }
}
